﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignement_2v2
{
    public static class Datetime
    {
        // The format for the date and time strings
        public const string DATETIMEFORMAT = "HH:mm dd/MM/yyyy";
    }
}
